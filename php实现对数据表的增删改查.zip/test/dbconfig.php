<?php
$conn= mysqli_connect("localhost", "root", "54088", "php");//四个参数分别是服务器名、用户名、密码、数据库名（在硬盘中）
mysqli_query($conn,"set names utf8");                            //设置数据库连接字符集支持汉字字段及内容
if($conn) 
{
	//echo "<br />&emsp;22软件301 99号 绅绅小宝贝 <br />";
	//echo "<br />&emsp;连接mySQL的系统数据库成功<br /><br />";
}
else
	echo "<br />&emsp;努力吧！连接mySQL数据库失败<br />";
?>
</body>
</html>