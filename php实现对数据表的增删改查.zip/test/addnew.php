<!DOCTYPE html>  
<html>  
<head lang="en">  
    <meta charset="UTF-8">  
    <title>添加</title>  
</head>
<body>
<form action="action-add.php" method="post">  
    <table align="center" valign="middle" border="1">
		<tr>
			<td>姓名：</td>
            <td><input class="input" type="text" name="uName" /></td>
        </tr>
        <tr>
			<td>密码：</td>
			<td><input class="input" type="password" id="uPwd" name="uPwd" /></td>
        </tr>
        <tr>
			<td>性别：</td>
			<td>
				<input type="radio" name="gender" value="0"  checked="checked" >男
				<input type="radio" name="gender"  value="1" >女
			</td>
        </tr>
        <tr>
			<td>用户类型：</td>
			<td>
				<input type="radio" name="uType" value="0" checked="checked" >管理员
				<input type="radio" name="uType"  value="1" >平民
			</td>
        </tr>
        <tr>
			<td colspan="3" align="center">
				<input class="submit" tabindex="5" type="submit" value="注册">
				<input  tabindex="6" type="button" value="取消" onclick="javascript:window.location='index.php';">
			</td>
        </tr>
	</table>
</form>  
</body>  
</html>