/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80036
 Source Host           : localhost:3306
 Source Schema         : php

 Target Server Type    : MySQL
 Target Server Version : 80036
 File Encoding         : 65001

 Date: 19/03/2024 10:56:01
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for usertable
-- ----------------------------
DROP TABLE IF EXISTS `usertable`;
CREATE TABLE `usertable`  (
  `ID` int NOT NULL AUTO_INCREMENT COMMENT '用户编号',
  `uName` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `uPass` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '密码',
  `gender` tinyint NULL DEFAULT NULL COMMENT '性别',
  `utype` bit(1) NULL DEFAULT NULL COMMENT '用户类别',
  `headimg` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '头像',
  `regTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 316 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of usertable
-- ----------------------------
INSERT INTO `usertable` VALUES (1, '余彬彬', 'C4CA4238A0B923820DCC509A6F75849B', 0, b'0', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (2, '黄漫', '334', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (3, '黄静', 'C4CA4238A0B923820DCC509A6F75849B', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (4, '张馨心', 'C4CA4238A0B923820DCC509A6F75849B', 0, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (5, '罗倩', 'C4CA4238A0B923820DCC509A6F75849B', 0, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (6, '彭晓燕', 'C4CA4238A0B923820DCC509A6F75849B', 0, b'0', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (7, '彭晓岚', 'C4CA4238A0B923820DCC509A6F75849B', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (8, '杨永康', 'C4CA4238A0B923820DCC509A6F75849B', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (9, '吴琦', 'C4CA4238A0B923820DCC509A6F75849B', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (10, '郭倩西', 'C4CA4238A0B923820DCC509A6F75849B', 0, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (11, '宋玉兰', 'C4CA4238A0B923820DCC509A6F75849B', 0, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (12, '杨帆', 'C4CA4238A0B923820DCC509A6F75849B', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (13, '李龙辉', 'C4CA4238A0B923820DCC509A6F75849B', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (14, '成航', 'C4CA4238A0B923820DCC509A6F75849B', 1, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (15, '周建飞', 'C4CA4238A0B923820DCC509A6F75849B', 0, b'1', NULL, '2024-03-06 00:00:00');
INSERT INTO `usertable` VALUES (325, 'man', '9999', 0, b'0', NULL, '2024-03-19 00:00:00');
INSERT INTO `usertable` VALUES (323, 'what can i say', 'manbaout', 0, b'1', NULL, '2024-03-19 00:00:00');
INSERT INTO `usertable` VALUES (315, 'see you again', '24', 0, b'1', NULL, '2024-03-18 00:00:00');
INSERT INTO `usertable` VALUES (326, 'some body', 'so', 0, b'1', NULL, '2024-03-19 00:00:00');
INSERT INTO `usertable` VALUES (324, '斐机北', '1008611', 1, b'1', NULL, '2024-03-19 00:00:00');

SET FOREIGN_KEY_CHECKS = 1;
