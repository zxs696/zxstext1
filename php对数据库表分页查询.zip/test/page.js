function del(id){ 
	if (confirm("确定删除这条数据吗？")){ 
		window.location = "action-del.php?id="+id;
	}
}
function add(){ window.location = "addnew.php"; }
function upd(id){ window.location = "updold.php?id="+id; }
function jump(c,r){
	   var page=document.getElementById("page").value;
	   if(/^\d+$/.test(page)){
		   if(page>0&&page<=c){
			   location.href="?page="+page+"&records_per_page="+r;
		   }else{
			   alert("页码必须在1到"+c+"之间!");
		   }
	   }else{
		   alert("页码不能为空,且必须是数值! ");
	   }
}
function selectOne(p,r){
	   location.href="?page="+p+"&records_per_page="+r;
}
function selectUp(p,r){
	   if((p-1)>0){
		   location.href="?page="+(p-1)+"&records_per_page="+r;
	   }else{
		   alert("已是首页!");
	   }
}
function selectDown(p,c,r){
	   if((p+1)<=c){
		   location.href="?page="+(p+1)+"&records_per_page="+r;
	   }else{
		   alert("已是尾页!");
	   }
}
