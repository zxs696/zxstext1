<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>修改</title>
</head>
<body>
<?php
    require "dbconfig.php";
    
    $id = $_GET['id'];
    $sql = mysqli_query($conn,"SELECT * FROM usertable WHERE id=$id");
    $sql_arr = mysqli_fetch_assoc($sql); 
?>
<form action="action-upd.php" method="post">
	<table align="center" valign="middle" border="1">
        <input class="input" type="hidden" name="id" value="<?php echo $sql_arr['ID']?>" />
		<tr>
			<td>姓名：</td>
			<td><input class="input" type="text" name="uName" value="<?php echo $sql_arr['uName']?>" /></td>
		</tr>
		<tr>
			<td>密码：</td>
			<td><input class="input" type="text" id="uPwd" name="uPwd" value="<?php echo $sql_arr['uPass']?>" /></td>
		</tr>
		<tr>
			<td>性别：</td>
			<td>
				<input type="radio" name="gender" value="0"  checked="checked" >男
				<input type="radio" name="gender"  value="1" >女
			</td>
		</tr>
		<tr>
			<td>用户类型：</td>
			<td>
				<input type="radio" name="uType" value="0" checked="checked" >管理员
				<input type="radio" name="uType"  value="1" >平民
			</td>
		</tr>
		<tr>
			<td colspan="3" align="center">
				<input class="submit" tabindex="5" type="submit" value="更新">
				<input  tabindex="6" type="button" value="取消" onclick="javascript:window.location='paging.php';">
			</td>
		</tr>
	</table>
</form>
<script language="javascript">
	var s="<?php echo $sql_arr['gender']?>";
	var gender=document.getElementsByName("gender");
	for(var i=0;i<gender.length;i++){
		if(gender[i].value==s){
			gender[i].checked=true;
			break;
		}
	}
	
	var t="<?php echo $sql_arr['utype']?>";
	var utype=document.getElementsByName("uType");
	for(var i=0;i<utype.length;i++){
		if(utype[i].value==t){
			utype[i].checked=true;
			break;
		}
	}
</script>
</body>
</html>
