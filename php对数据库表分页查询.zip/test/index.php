<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Query</title>
<style>
	td
	{
		text-align:center;
	}
</style>
<script language="javascript">
	function del(id){ 
		if (confirm("确定删除这条数据吗？")){ 
			window.location = "action-del.php?id="+id;
		 }
	}
	function add(){ window.location = "addnew.php"; }
	function upd(id){ window.location = "updold.php?id="+id; }
</script>
<?php
	function Gender($x){
		$mf = array(0 => '男性' , 1 => '女性');
		return $mf[$x];
	}
	function Utype($y){
		$ac = array(0 => '管理员' , 1 => '平民');
		return $ac[$y];
	}
?>      
</head>
<body>
	<table align="center" valign="middle" border="1">
		<tr>
			<th>id</th>
			<th>名字</th>
			<th>密码</th>
			<th>性别</th>
			<th>用户类型</th>
			<th>图片</th>
			<th>注册时间</th>
			<th>操作</th>
			<th><button onclick='add()'>添加</button></th>
		</tr>
			
		<?php
			// 1.导入配置文件
			require 'dbconfig.php';
			//sql语句
			$sql = 'select * from usertable order by id';
			$retval = mysqli_query($conn, $sql);	//执行
			//不加判断会报错
			if (!$retval) {
				printf("Error: %s\n", mysqli_error($conn));
				exit();
			}
				
			//返回记录数
			$row_length = mysqli_num_rows($retval);
				
			//循环遍历出数据表中的数据
			for ($i=0; $i<$row_length; $i++) {		
			//从结果集中取得一行作为关联数组
				$row = mysqli_fetch_assoc($retval);
				echo "<tr>";
				echo "<td>{$row['ID']}</td>";
				echo "<td>{$row['uName']}</td>";
				echo "<td>{$row['uPass']}</td>";
				echo "<td>".Gender($row['gender'])."</td>";
				echo "<td>".Utype($row['utype'])."</td>";
				echo "<td>{$row['headimg']}</td>";
				echo "<td>{$row['regTime']}</td>";
				echo "<td><button onclick = 'del({$row['ID']})'>删除</button></td>";
				echo "<td><button onclick = 'upd({$row['ID']})'>更新</button></td>";
				echo "</tr>";
			};
			//echo "<tr><td colspan='9'><button>上一页</button><button>下一页</button></td></tr>";
			mysqli_close($conn);
		?>
	</table>
</body>
</html>