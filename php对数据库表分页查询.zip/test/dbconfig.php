<!DOCTYPE html >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>dbconfig</title>
</head>
<body>
	<div align="center">
		<?php
			$host = "localhost";
			$user = "root";
			$upwd = "54088";
			$dbase = "php";
			$conn= mysqli_connect($host, $user, $upwd, $dbase);//四个参数分别是服务器名、用户名、密码、数据库名（在硬盘中）
			mysqli_query($conn,"set names utf8");                            //设置数据库连接字符集支持汉字字段及内容
			if($conn) echo "Connect $dbase Succeed！";
			else echo "Connect $dbase Unsucceed！";
		?>
	</div>
</body>
</html>