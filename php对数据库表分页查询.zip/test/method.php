<?php
	function Gender($x){
		$mf = array(0 => '男性' , 1 => '女性');
		return $mf[$x];
	}
	function Utype($y){
		$ac = array(0 => '管理员' , 1 => '平民');
		return $ac[$y];
	}
	function selectPage($page,$records_per_page){
		// 数据库配置
		require 'dbconfig.php';
		
		// 计算查询的起始位置
		$start_from = ($page - 1) * $records_per_page;

		// 查询数据库记录
		$sql = "SELECT * FROM usertable LIMIT $start_from, $records_per_page";
		$result = $conn->query($sql);

		while ($row = $result->fetch_assoc()) {
			// 处理查询结果，例如输出
		echo "<tr>";
		echo "<td>{$row['ID']}</td>";
		echo "<td>{$row['uName']}</td>";
		echo "<td>{$row['uPass']}</td>";
		echo "<td>".Gender($row['gender'])."</td>";
		echo "<td>".Utype($row['utype'])."</td>";
		echo "<td>{$row['headimg']}</td>";
		echo "<td>{$row['regTime']}</td>";
		echo "<td><button id='del' onclick = 'del({$row['ID']})'>删除</button></td>";
		echo "<td><button id='upd' onclick = 'upd({$row['ID']})'>更新</button></td>";
		echo "</tr>";
		}
		// 计算总记录数以及总页数
		$sql = "SELECT COUNT(*) AS total FROM usertable";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$total_records = $row["total"];
		$total_pages = ceil($total_records / $records_per_page);
		$start_page = max(1, min($page - floor(5 / 2), $total_pages - 5 + 1));
		$end_page = min($total_pages, max($page + ceil(5 / 2) - 1, 5));
		echo "<tr>";
		echo "<td colspan='9' align='center'>";
		echo "<button onclick='selectOne(1,$records_per_page)'>首页</button>";
		echo "<button onclick='selectUp($page,$records_per_page)'>上一页</button>";

		// 输出分页链接
		for ($i = $start_page; $i <= $end_page; $i++) {
			if ($i == $page) {
				//echo "<a href='?page=$i&records_per_page=$records_per_page'>$i</a> ";
				echo "<button id='p' onclick='selectOne($i,$records_per_page)'>$i</button>";
				//echo "<span class='current'>$i</span>";
			}else{
				echo "<button onclick='selectOne($i,$records_per_page)'>$i</button>";
			}
		}
		echo "<button onclick='selectDown($page,$total_pages,$records_per_page )'>下一页</button>";
		echo "<button onclick='selectOne($total_pages,$records_per_page)'>尾页</button>";
		echo "<input type='text' size='2' id='page'/>";
		echo "<input type='button' value='GO' onclick='jump($total_pages,$records_per_page)'/>";
		// 输出每页显示数量的下拉框
		echo "<form action='' method='get' style='margin:0px;display: inline'>";
		echo "<select name='records_per_page' onchange='this.form.submit()'>";
		$options = [5, 10, 20, 30];
		foreach ($options as $option) {
			$selected = $option == $records_per_page ? "selected" : "";
			echo "<option value='$option' $selected>每页显示：$option</option>";
		}
		echo "</select>";
		echo "</form>";
		echo "</td>";
		echo "</tr>";
		mysqli_close($conn);
	}
?>
