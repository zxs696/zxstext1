<?php
// 处理删除操作的页面 
require "dbconfig.php";
$id = $_GET['id'];
//删除指定数据  
mysqli_query($conn,"DELETE FROM usertable WHERE ID={$id}") or die('删除数据出错：'.mysqli_error()); 
header("Location:paging.php");  
?>


