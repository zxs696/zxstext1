<?php
// 处理增加操作的页面 
require "dbconfig.php";
$uName = $_POST['uName'];
$uPwd = $_POST['uPwd'];
$gender = $_POST['gender'];
$uType = $_POST['uType'];
// 插入数据
$sql = "INSERT INTO usertable VALUES(null,'$uName','$uPwd',$gender,$uType,null,CURDATE())";
mysqli_query($conn,$sql) or die('添加数据出错：'.mysqli_error()); 
header("Location:paging.php");  
?>
