<!DOCTYPE html >
<html>
<head>
	<meta charset=utf-8" />
	<title>paging</title>
	<link type="text/css" rel="styleSheet"  href="hello.css" />
	<script type="text/javascript" src="page.js"></script>
</head>
<body>
	<table align="center" valign="middle" border="1" cellspacing="0">
		<tr>
			<th>id</th>
			<th>名字</th>
			<th>密码</th>
			<th>性别</th>
			<th>用户类型</th>
			<th>图片</th>
			<th>注册时间</th>
			<th>操作</th>
			<th id="adds"><button id ="add" onclick='add()'>添加</button></th>
		</tr>
	<?php
		require 'method.php';
		// 获取当前页数
		$page = isset($_GET["page"]) ? (int)$_GET["page"] : 1;
		// 获取每页显示的记录数
		$records_per_page = isset($_GET["records_per_page"]) ? (int)$_GET["records_per_page"] : 10;
		selectPage($page,$records_per_page);
	?>
	</table>
</body>
</html>