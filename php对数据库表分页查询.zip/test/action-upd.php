<?php
// 处理编辑操作的页面 
require "dbconfig.php";
$id = $_POST['id'];
$uName = $_POST['uName'];
$uPwd = $_POST['uPwd'];
$gender = $_POST['gender'];
$uType = $_POST['uType'];
// 更新数据
mysqli_query($conn,"UPDATE usertable SET uName='$uName',uPass='$uPwd',gender=$gender,uType=$uType where ID={$id}") or die('修改数据出错：'.mysqli_error()); 
header("Location:paging.php");
?>